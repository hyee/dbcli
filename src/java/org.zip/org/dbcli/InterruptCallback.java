package org.dbcli;

import java.awt.event.ActionEvent;

/**
 * Created by Will on 2015/9/15.
 */
public interface InterruptCallback {
    public void interrupt(ActionEvent e) throws Exception;
}
